﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;
using System.Drawing;










namespace Elevator
{






    //In Order to Close The door



    class CloseOpen
    {




        public void CloseDoor(PictureBox door_left_up, PictureBox door_right_up,
            PictureBox door_left_down, PictureBox door_right_down)
        {
            if (door_left_up.Left <= 110 && door_right_up.Left >= 162)




            {



                // This Shifts the door to the right with increment of 1
                door_left_up.Left += 1;

               
                
                //This Shifts the door to the left with increment of 1
                door_right_up.Left -= 1;



            }

            else if (door_left_down.Left <= 110 && door_right_down.Left >= 162)
            {

                //This Shifts the door with the increment of 1 to the left
                door_right_down.Left -= 1;




                //This Shifts the door with increment of 1 to the right
                door_left_down.Left += 1; 
                
                
  
            }

            
        }










        //In order to Open the Door
        public void OpenDoor(PictureBox door_left_up, PictureBox door_right_up, 
            
            PictureBox door_left_down, PictureBox door_right_down)
        
        
        {
            
            
            if (door_left_up.Left >= 61 && door_right_up.Left <= 208)
            {






                // This Shifts the door to the right with increment of 1
                door_right_up.Left += 1;





                // This Shifts the door to the left with increment of 1

                door_left_up.Left -= 1;



            
            
            }



            else if (door_left_down.Left >= 61 && door_right_down.Left <= 208)
            {



                // This Shifts the door to the right with increment of 1

                door_right_down.Left += 1;



                // This Shifts the door to the left with increment of 1


                door_left_down.Left -= 1;



            }
        
        
        }



   
    
    }
}
