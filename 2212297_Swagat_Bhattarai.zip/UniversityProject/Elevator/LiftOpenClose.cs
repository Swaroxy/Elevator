﻿using System.Windows.Forms;

namespace Elevator
{
    class LiftOpenClose
    {


        //Code to make the elevator go up


        public void lift_up(PictureBox picture_lift)
        
        {

            
            if (picture_lift.Top >= 51)

            {

                picture_lift.Top -= 1; 
            
            }
        
        }






        // Code to make the elevator go Down
        public void lift_down(PictureBox picture_lift)

        {

            if (picture_lift.Top <= 352)
            {

                picture_lift.Top += 1; 
            
            }
        
        }



    }
}
