﻿using System;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Elevator
{
    class GlobalConnection
    {
        public static OleDbConnection cn;


        public static void DbConnection()


            // required code for global database connection


        {
            try

            {

                cn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=ElevatorLog.mdb");
                cn.Open();
            
            
            }
            catch(Exception ex)
            {

                MessageBox.Show(ex.Message);
            
            }
        }
    }
}
